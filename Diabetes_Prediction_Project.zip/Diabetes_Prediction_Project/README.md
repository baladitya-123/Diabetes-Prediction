# Diabetes Prediction Using Machine Learning

This project predicts whether a person is diabetic or not using Machine Learning.

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn

## Algorithm Used
- Logistic Regression

## How to Run
1. Install requirements:
   pip install -r requirements.txt

2. Run:
   python main.py
